package com.example.cs360inventoryapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.widget.Button;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        Switch smsSwitch = findViewById(R.id.switch1);

        smsSwitch.setChecked(checkSendSmsPermission());

        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                grantPermissionForSMS();
            } else {
                denyPermissionForSMS();
            }
        });

        Button inventoryButton = findViewById(R.id.inventoryButton);

        inventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start the SettingsActivity when the button is clicked
                Intent intent = new Intent(SettingsActivity.this, DatabaseActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean checkSendSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void grantPermissionForSMS() {
        Toast.makeText(this, "Permission granted for SMS notifications", Toast.LENGTH_SHORT).show();
    }

    private void denyPermissionForSMS() {
        Toast.makeText(this, "Permission denied for SMS notifications", Toast.LENGTH_SHORT).show();
    }
}

